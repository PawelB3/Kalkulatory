from enum import Enum

class HarmonogramWyplat(Enum):
    roczne = 1
    polroczne = 2
    kwartalne = 6
    miesieczne = 12